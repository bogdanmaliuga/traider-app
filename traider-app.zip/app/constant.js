(function() {
    angular.module('TraiderApp')
    .constant('CONSTANT',{"API_URL":"http://localhost:8080"})



}());
