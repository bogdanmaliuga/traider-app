(function() {
    angular.module('TraiderApp')
        .controller('HomeController', ['UserService','Storage','$scope','$state','AuthTokenFactory', function(UserService,Storage,$scope,$state,AuthTokenFactory) {
            

        }]);
}());
