module.exports = {

    'secret': 'lily',
    'database': 'mongodb://localhost:27017/traider',
    'database2': 'mongodb://admin:admin@ds145415.mlab.com:45415/traider'


};